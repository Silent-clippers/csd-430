// Keanu Module 5/6 6/25/25

package coffeeBeans;
import java.io.Serializable;
import java.sql.*;
import java.util.*;

public class KeanuMovieBean implements java.io.Serializable {
	private static final long serialVersionUID = 111222333444L;
	private String dbURL = "jdbc:mysql://localhost:3306/CSD340";
	private String username = "student1";
	private String password = "pass";
	
	public Connection getConnection() throws SQLException {
		return DriverManager.getConnection(dbURL, username, password);
	}
	
	public List<Integer> getAllMovieIDs() {
		List<Integer> ids = new ArrayList<>();
		try (Connection conn = getConnection();
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT movie_id FROM keanu_movies_data")) {
			while (rs.next()) {
				ids.add(rs.getInt("movie_id"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ids;		
	}
	
	public Map<String, String> getMovieByID(int id) {
		Map<String, String> movie = new LinkedHashMap<>();
		String sql = "SELECT * FROM keanu_movies_data WHERE movie_id = ?";
		try (Connection conn = getConnection();
				PreparedStatement stmt = conn.prepareStatement(sql)) {
			stmt.setInt(1, id);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				movie.put("Movie ID", String.valueOf(rs.getInt("movie_id")));
				movie.put("Title", rs.getString("title"));
				movie.put("Genre", rs.getString("genre"));
				movie.put("Release Year", String.valueOf(rs.getInt("release_year")));
				movie.put("Rating", String.valueOf(rs.getDouble("rating")));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return movie;
	}
	
}



